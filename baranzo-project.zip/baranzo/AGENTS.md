<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## App architecture
- Keep the public studio homepage at the index route and use section anchors for its single-page navigation, so every primary action stays within the same experience.
- Define all visual roles and responsive presentation in the global design system; use shared Button variants for actions to maintain consistent theming.
- Import uploaded brand imagery through asset pointer JSON files rather than repository binaries, so original media stays in managed asset storage.
- Use the shared Radix Dialog primitives for modal interactions, so keyboard focus, Escape dismissal, and focus restoration remain accessible.
- Public form submissions (e.g. consultation requests) are inserted from server functions via the service-role client; their tables stay RLS-locked with no anon/authenticated policies so visitors can never read or modify submissions.
