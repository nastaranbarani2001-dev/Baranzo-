import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { ArrowUpLeft, ArrowDown, Plus, Minus, Menu, X, Check, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { submitConsultationRequest } from "@/lib/consultation.functions";
import portrait from "@/assets/portrait.asset.json";
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import logo from "@/assets/logo.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "بارانزو | استودیو رشد دیجیتال و آموزش هوش مصنوعی" },
    { name: "description", content: "رشد هوشمند کسب‌وکارها با بارانزو؛ مدیریت اینستاگرام، تولید محتوای هوش مصنوعی و آموزش عملی ادمینی." },
    { property: "og:title", content: "بارانزو | خلاقیت انسانی، رشد هوشمند" },
    { property: "og:description", content: "استودیو رشد دیجیتال و آموزش تخصصی؛ پیوند استراتژی، خلاقیت و هوش مصنوعی." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

const services = [
  { en: "Instagram Management", title: "مدیریت حرفه‌ای اینستاگرام", text: "از تدوین تقویم محتوا تا انتشار و تحلیل؛ حضوری یکپارچه و هدفمند برای برند شما.", tags: "استراتژی محتوا · مدیریت پیج · تحلیل عملکرد" },
  { en: "AI Content Studio", title: "خلق محتوا با هوش مصنوعی", text: "ایده‌های انسانی، همراه با قدرت هوش مصنوعی؛ محتوایی متمایز و هم‌راستا با هویت برند شما.", tags: "ایده‌پردازی · محتوای تصویری · سناریونویسی" },
  { en: "Digital Growth Strategy", title: "استراتژی برند و رشد دیجیتال", text: "ساخت مسیر اختصاصی رشد؛ از شناخت مخاطب و جایگاه برند تا طراحی سیستم‌های محتوایی کسب‌وکار.", tags: "مشاوره رشد · هویت برند · سیستم‌سازی" },
];

function Index() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeService, setActiveService] = useState<number | null>(0);
  const [courseOpen, setCourseOpen] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [consultSending, setConsultSending] = useState(false);
  const [consultSent, setConsultSent] = useState(false);
  const [consultError, setConsultError] = useState("");
  const submitConsultation = useServerFn(submitConsultationRequest);
  const nav = [{ label: "درباره بارانزو", id: "about" }, { label: "خدمات", id: "services" }, { label: "آکادمی بارانزو", id: "academy" }, { label: "داستان من", id: "founder" }];

  const handleConsultSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    setConsultSending(true);
    setConsultError("");
    const result = await submitConsultation({ data: {
      name: String(data.get("name") ?? ""),
      contact: String(data.get("contact") ?? ""),
      topic: String(data.get("topic") ?? ""),
      message: String(data.get("message") ?? ""),
    } });
    setConsultSending(false);
    if (result.ok) { setConsultSent(true); form.reset(); } else setConsultError(result.error || "ارسال انجام نشد؛ لطفاً دوباره تلاش کنید.");
  };

  return (
    <>
      <a className="skip-link" href="#main-content">رفتن به محتوای اصلی</a>
      <header className="site-header page-width">
        <a href="#" className="brand" aria-label="بارانزو، صفحه اصلی"><img src={logo.url} alt="BARANZO AI" /><span className="brand-caption">DIGITAL GROWTH STUDIO</span></a>
        <nav className="desktop-nav" aria-label="منوی اصلی">{nav.map(item => <a key={item.id} href={`#${item.id}`}>{item.label}</a>)}</nav>
        <Button asChild variant="studio" className="header-cta"><a href="#contact">شروع یک گفت‌وگو <ArrowUpLeft /></a></Button>
        <Button variant="ghost" size="icon" className="mobile-menu-toggle" aria-label={menuOpen ? "بستن منو" : "باز کردن منو"} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</Button>
      </header>
      {menuOpen && <nav id="mobile-navigation" className="mobile-nav" aria-label="منوی موبایل">{nav.map(item => <a key={item.id} href={`#${item.id}`} onClick={() => setMenuOpen(false)}>{item.label}</a>)}<a href="#contact" onClick={() => setMenuOpen(false)}>شروع همکاری <ArrowUpLeft size={16} /></a></nav>}

      <main id="main-content">
      <section className="hero" aria-labelledby="hero-title">
        <img className="hero-photo" src={portrait.url} alt="نسترن بارانی، بنیان‌گذار بارانزو، با لباس مشکی پشت میز کار" fetchPriority="high" />
        <div className="hero-shade" aria-hidden="true" />
        <div className="hero-inner page-width">
          <div className="hero-copy">
            <div className="eyebrow hero-eyebrow">استودیو رشد دیجیتال و هوش مصنوعی</div>
            <h1 id="hero-title">رشد هوشمند کسب‌وکارها<br />با <span className="latin-inline">AI</span> و سیستم‌های دیجیتال</h1>
            <p>جایی که خلاقیت انسانی و هوش مصنوعی،<br className="desktop-break" /> مسیر تازه‌ای برای رشد برند شما می‌سازند.</p>
          </div>
          <div className="hero-wordmark" dir="ltr">BARANZO<span>®</span></div>
          <div className="hero-actions"><Button asChild variant="ivory" size="lg"><a href="#contact">شروع همکاری <ArrowUpLeft /></a></Button><Button asChild variant="glass" size="lg"><a href="#academy">مشاهده دوره‌ها</a></Button></div>
          <div className="hero-bottom"><span dir="ltr">STRATEGY. CREATIVITY. INTELLIGENCE.</span><a href="#about"><ArrowDown size={17} /><span>کمی بیشتر آشنا شویم</span></a></div>
        </div>
      </section>

      <section id="about" className="about-section section-space page-width">
        <div><div className="eyebrow"><span className="small-line" /> فلسفه بارانزو <span className="section-number">۰۱</span></div><h2>فقط دیده نشوید؛<br /><span className="text-muted-foreground">اثرگذار باشید.</span></h2></div>
        <div className="about-copy"><p className="lead">رشد، اتفاقی نیست.<br />حاصل یک نگاه خلاق و یک سیستم هوشمند است.</p><p>بارانزو، پیوند استراتژی محتوا، تخصص اینستاگرام و قدرت هوش مصنوعی است. کنار کسب‌وکارها هستیم تا حضور دیجیتال‌شان را هدفمند بسازند؛ و کنار کسانی که می‌خواهند این مسیر را حرفه‌ای یاد بگیرند.</p><a className="text-link" href="#founder">داستان پشت بارانزو <ArrowUpLeft size={18} /></a></div>
      </section>

      <div className="discipline-strip" dir="ltr"><span>HUMAN CREATIVITY</span><span className="strip-star">✳</span><span>ARTIFICIAL INTELLIGENCE</span><span className="strip-star">✳</span><span>MEANINGFUL GROWTH</span><span className="strip-star">✳</span><span>BARANZO STUDIO</span></div>

      <section id="services" className="section-space page-width">
        <div className="section-heading"><div><div className="eyebrow"><span className="small-line" /> تخصص ما <span className="section-number">۰۲</span></div><h2>برای قدم بعدی برند شما.</h2></div><p>از اولین ایده، تا یک حضور ماندگار.</p></div>
        <div className="services-list">{services.map((service, index) => <article key={service.en} className={`service-row ${activeService === index ? "is-open" : ""}`}><Button className="service-trigger" variant="ghost" onClick={() => setActiveService(activeService === index ? null : index)} aria-expanded={activeService === index} aria-controls={`service-${index}`}><span className="service-index">۰{index + 1}</span><span className="service-name"><span>{service.title}</span><span className="service-en" dir="ltr">{service.en}</span></span><span className="service-plus">{activeService === index ? <Minus /> : <Plus />}</span></Button>{activeService === index && <div className="service-detail" id={`service-${index}`}><p>{service.text}</p><span>{service.tags}</span><a className="text-link" href="#contact">درباره پروژه‌تان صحبت کنیم <ArrowUpLeft size={17} /></a></div>}</article>)}</div>
      </section>

      <section id="academy" className="academy-section"><div className="page-width academy-grid section-space"><div><div className="eyebrow"><span className="small-line" /> آکادمی بارانزو <span className="section-number">۰۳</span></div><h2>مهارتی برای امروز.<br /><span className="text-muted-foreground">فرصتی برای فردا.</span></h2><p className="academy-intro">یادگیری از دل تجربه؛ برای کسانی که به یک شروع معمولی قانع نیستند.</p><Button variant="studio" size="lg" onClick={() => setCourseOpen(!courseOpen)} aria-expanded={courseOpen}> {courseOpen ? "بستن سرفصل‌ها" : "آشنایی با دوره"} {courseOpen ? <Minus /> : <ArrowUpLeft />}</Button></div><div className="course-content"><div className="course-label"><span dir="ltr">BARANZO ACADEMY</span><Sparkles size={21} /></div><h3>دوره ادمینی اینستاگرام<br />از صفر تا حرفه‌ای</h3><p>از ساخت محتوا تا طراحی مسیر رشد؛<br />با ابزارهای نسل جدید و پروژه‌های واقعی.</p><div className="course-tags"><span>آموزش پروژه‌محور</span><span>ابزارهای AI</span><span>پشتیبانی نامحدود</span></div>{courseOpen && <div className="course-syllabus"><h4>مسیر یادگیری شما</h4><ul>{["مبانی مدیریت پیج و استراتژی رشد اینستاگرام", "ایده‌پردازی و تولید محتوا با هوش مصنوعی", "تدوین، ویرایش و اجرای پروژه‌های واقعی"].map(text => <li key={text}><Check size={16} aria-hidden="true" />{text}</li>)}</ul><a className="text-link" href="#contact">درخواست اطلاعات ثبت‌نام <ArrowUpLeft size={16} /></a></div>}<div className="course-footer"><span>LEARN. CREATE. GROW.</span><span>مسیر حرفه‌ای تو، از اینجا</span></div></div></div></section>

      <section id="founder" className="founder-section section-space page-width"><div className="founder-wordmark" aria-hidden="true"><span dir="ltr">BARANZO</span><span dir="ltr">THE HUMAN BEHIND THE BRAND</span></div><div className="founder-copy"><div className="eyebrow"><span className="small-line" /> پشت نام بارانزو <span className="section-number">۰۴</span></div><h2>با نگاه انسانی.<br />با قدرت تکنولوژی.</h2><p className="founder-quote">«باور دارم آینده متعلق به کسانی است که خلاقیت را با تکنولوژی همراه می‌کنند.»</p><p>من نسترن بارانی هستم. بارانزو را برای پیوند دادن خلاقیت، آموزش کاربردی و رشد واقعی کسب‌وکارها شکل دادم؛ فضایی که در آن، ابزارهای هوشمند جای نگاه انسانی را نمی‌گیرند، بلکه به آن قدرت می‌دهند.</p><div className="founder-signature">نسترن بارانی<span>بنیان‌گذار بارانزو</span></div></div></section>

      <section id="consultation" className="consult-section section-space page-width">
        <div className="consult-grid">
          <div>
            <div className="eyebrow"><span className="small-line" /> درخواست مشاوره</div>
            <h2>مسیر بعدی برند شما،<br />از یک گفت‌وگو کوتاه.</h2>
            <p className="consult-intro">فرم کوتاه را پر کنید تا درباره ایده‌ها و مسیر رشد شما، در اولین فرصت با شما تماس بگیریم.</p>
            <div className="consult-note" dir="ltr">BARANZO CONSULTATION</div>
          </div>
          {consultSent ? (
            <div className="consult-success" role="status"><Check size={20} /><p>درخواست شما ثبت شد.</p><span>به‌زودی برای هماهنگی گفت‌وگو با شما تماس می‌گیریم.</span></div>
          ) : (
            <form className="consult-form" onSubmit={handleConsultSubmit}>
              <label>نام و نام خانوادگی<input name="name" required placeholder="نام شما" maxLength={100} /></label>
              <label>شماره تماس یا ایمیل<input name="contact" required placeholder="0912…" dir="ltr" maxLength={255} /></label>
              <label>موضوع گفت‌وگو<select name="topic"><option>خدمات و همکاری</option><option>مشاوره رشد</option><option>دوره ادمینی اینستاگرام</option></select></label>
              <label>توضیح کوتاه<textarea name="message" rows={3} maxLength={2000} placeholder="در یک یا دو خط بگویید…" /></label>
              <Button variant="studio" size="lg" type="submit" disabled={consultSending}>{consultSending ? "در حال ارسال…" : <>ارسال درخواست مشاوره <ArrowUpLeft /></>}</Button>
              {consultError && <p className="consult-error" role="alert">{consultError}</p>}
            </form>
          )}
        </div>
      </section>

      <Dialog open={contactOpen} onOpenChange={setContactOpen}>
      <section id="contact" className="contact-section section-space"><div className="page-width"><div className="eyebrow"><span className="status-dot" /> برای ایده‌های تازه، آماده‌ایم.</div><div className="contact-heading"><h2>قدم بعدی را<br />با هم برداریم.</h2><DialogTrigger asChild><Button variant="ivory" className="contact-arrow" aria-label="آماده کردن درخواست همکاری" onClick={() => setCopied(false)}><ArrowUpLeft /></Button></DialogTrigger></div><div className="contact-bottom"><p>یک ایده، یک سؤال، یا شروع یک همکاری تازه.</p><span dir="ltr">LET’S MAKE IT MEANINGFUL.</span></div></div></section>

      <DialogContent className="contact-dialog" dir="rtl"><div className="eyebrow">شروع یک گفت‌وگو</div><DialogTitle>از ایده‌تان بگویید.</DialogTitle><DialogDescription className="sr-only">درخواست همکاری خود را برای کپی و اشتراک‌گذاری آماده کنید.</DialogDescription><form onSubmit={async event => { event.preventDefault(); const data = new FormData(event.currentTarget); try { await navigator.clipboard.writeText(`درخواست همکاری با بارانزو\nنام: ${data.get("name")}\nموضوع: ${data.get("topic")}\n${data.get("message")}`); setCopied(true); } catch { setCopied(false); } }}><label>نام شما<input name="name" required placeholder="نام و نام خانوادگی" /></label><label>موضوع گفت‌وگو<select name="topic"><option>خدمات و همکاری</option><option>مشاوره رشد</option><option>دوره ادمینی اینستاگرام</option></select></label><label>ایده یا سؤال شما<textarea name="message" required rows={3} placeholder="کمی درباره آن بنویسید…" /></label><p className="form-note">درخواست شما برای اشتراک‌گذاری کپی می‌شود؛ از این فرم پیامی ارسال نمی‌شود.</p><Button variant="studio" size="lg" type="submit">{copied ? <><Check /> درخواست کپی شد</> : <>کپی درخواست همکاری <ArrowUpLeft /></>}</Button><span role="status" className="sr-only">{copied ? "متن درخواست در حافظه کپی شد" : ""}</span></form></DialogContent>
      </Dialog>
      </main>
      <footer className="site-footer page-width"><a href="#" className="footer-brand" dir="ltr">BARANZO<span>AI DIGITAL STUDIO</span></a><p>خلاقیت انسانی. رشد هوشمند.</p><a href="#" className="back-top">بازگشت به بالا <ArrowDown size={14} /></a><span className="copyright" dir="ltr">© 2026 BARANZO</span></footer>

    </>
  );
}