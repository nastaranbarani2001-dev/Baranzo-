import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const consultationSchema = z.object({
  name: z.string().trim().min(2).max(100),
  contact: z.string().trim().min(5).max(255),
  topic: z.string().trim().min(2).max(80),
  message: z.string().trim().max(2000).optional().default(""),
});

export const submitConsultationRequest = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => input)
  .handler(async ({ data }) => {
    const parsed = consultationSchema.safeParse(data);
    if (!parsed.success) return { ok: false as const, error: "اطلاعات فرم معتبر نیست؛ لطفاً فیلدها را بررسی کنید." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Light abuse guard: at most 3 requests per contact within 10 minutes.
    const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const { count } = await supabaseAdmin
      .from("consultation_requests")
      .select("id", { count: "exact", head: true })
      .eq("contact", parsed.data.contact)
      .gte("created_at", tenMinutesAgo);
    if ((count ?? 0) >= 3) {
      return { ok: false as const, error: "تعداد درخواست‌های ثبت‌شده از سمت شما زیاد است؛ لطفاً بعداً تلاش کنید." };
    }

    const { error } = await supabaseAdmin.from("consultation_requests").insert({
      name: parsed.data.name,
      contact: parsed.data.contact,
      topic: parsed.data.topic,
      message: parsed.data.message || null,
    });
    if (error) return { ok: false as const, error: "ارسال درخواست انجام نشد؛ لطفاً دوباره تلاش کنید." };
    return { ok: true as const };
  });
