# Baranzo visual refinement
- [x] Create the premium Persian homepage with original brand assets.
- [x] Establish generous spacing and professional typography across sections.
- [x] Verify desktop/mobile presentation and primary navigation.
- [x] Add a consultation request section with a short form that stores submissions in the database (owner email not yet wired — needs a verified sending domain).
- [x] Replace the framed hero with the new portrait and reference-inspired palette while preserving core content.
- [x] Remove the repeated portrait and refine mobile reading and touch targets.
- [x] Fix modal accessibility and verify mobile/desktop interactions and existing tests.